sbcl --script qa-out.lisp
